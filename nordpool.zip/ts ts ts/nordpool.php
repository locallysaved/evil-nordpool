<?php
$data = file_get_contents("https://lax.lv/nordpool.json");
$data2 = file_get_contents("https://lax.lv/nordpool2.json");
$apiData = json_decode($data, true);
$apiData2 = json_decode($data2, true);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nord uhhh nord kautkas</title>
</head>
<body>
    <div class="whole-thing">
        <div class="top-row round-1 w-100 flex fancy-font bold bshad-def">
            <div class="font-big pl-4 v-center color-dgreen flex fl-row">Nordpool<p class="font-small">(work in progress)</p></div>
        </div>
        <div class="main-box round-1 flex fl-row pl-1 mt-15">
<!-- ENTIRE LEFT SIDE -->
            <div class="flex fl-col w-50 h-maxcont flex">
<!-- FILTER AND EXTRA INFO DISPLAY -->
                <div class="flex v-center fl-row mt-1">
                    <div class="filters-area round-full ml-2 bshad-def flex v-center bgcol-w1 border-gr1 ml-1 w-5 flex fl-col pt-1">Sort by:
                        <div class="filter-hover w-5 flex fl-col mt-1 zIndex-1 left-0 bgcol-q1">
                            <button class="filterByTimeBtn h-fitContent bgcol-w1 border-gr1 pt-5 pb-5 hover-point">Time</button>
                            <button class=" filterByPriceBtn bgcol-w1 border-gr1 pt-5 pb-5 hover-point">Price</button>
                            <button class=" filterByHappyHrsBtn bgcol-w1 border-gr1 pt-5 pb-5 hover-point roundBottom-1">Happy hours by price</button>
                        </div>
                    </div>
                    <div class="space-btwn flex w-100 pl-8" style="margin-top: -0.5rem">
                        <div class="filters-info">
                            <p>Units:</p>
                            <?php echo $apiData['units'] ?></div>
                            <div class="filters-info">
                                <p>Timezone:</p>
                                <?php echo $apiData['timeZone'] ?></div>
                            <div class="filters-info">
                                <p>Last updated:</p>
                                <?php echo $apiData['updated'] ?></div>
                            <div class="filters-info">
                                <p>Time Now:</p>
                                <?php echo $apiData['priceFromNow']['hour'] ?>:00</div>
                            <div class="filters-info">
                                <p>Average:</p>
                                <?php echo $apiData['last30Days']['average'] ?></div>
                            
                        </div>
                    </div>
<!-- WHITE INCASING BOX ON THE LEFT -->
                <div class="stats-box mt-1 round-1 border-gr1">
                    <div class="dataArea v-align h-align round-1">
<!-- UH.... FIFLTER BY TIME FROM NOW.... -->
                        <div class="filterByTime">
                            <div class="statBoxes"><p>2024-08-10 17:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-10 17:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-10 19:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-10 19:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-10 20:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-10 20:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-10 21:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-10 21:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-10 22:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-10 22:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-10 23:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-10 23:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-18 01:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 01:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 01:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 02:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 03:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 03:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 04:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 04:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 05:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 05:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 06:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 06:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 08:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 08:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 09:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 09:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 11:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 11:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 12:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 12:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 13:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 13:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 14:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 14:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 15:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 15:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 16:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 16:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 17:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 17:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 19:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 19:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 20:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 20:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 21:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 21:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-11 23:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-11 22:00:00'] ?></div>
                            <div class="statBoxes"><p>2024-08-12 00:00:00</p><?php echo $apiData['priceFromNow']['hours']['2024-08-12 00:00:00'] ?></div>
                        </div>
<!-- FILTER BY PRICE -->
                        <div class="filterByPrice">
                        <div class="statBoxes"><p>2024-08-10 12:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 12:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 13:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 13:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 14:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 14:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 16:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 16:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 15:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 15:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 17:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 17:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 11:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 11:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 10:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 10:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 18:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 18:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 09:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 09:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 19:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 19:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 01:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 01:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 08:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 08:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 05:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 05:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 04:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 04:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 00:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 00:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 03:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 03:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 06:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 06:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 02:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 02:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 07:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 07:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 20:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 20:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 23:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 23:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 22:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 22:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 21:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 21:00:00'] ?></div>
                        </div>

                        <div class="filterByHappyHrs">
                            <div class="statBoxes"><p class="bold">Upcoming happy hours:</p></div>
                        <div class="statBoxes"><p>2024-08-10 17:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 17:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 18:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 18:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 19:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 19:00:00'] ?></div>
                        <div class="statBoxes"><p class="bold">Happy hours:</p></div>
                        <div class="statBoxes"><p>2024-08-10 12:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 12:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 13:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 13:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 14:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 14:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 16:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 16:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 15:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 15:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 17:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 17:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 11:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 11:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 10:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 10:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 18:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 18:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 09:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 09:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 19:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 19:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 01:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 01:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 08:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 08:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 05:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 05:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 04:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 04:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 00:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 00:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 03:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 03:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 06:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 06:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 02:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 02:00:00'] ?></div>
                        <div class="statBoxes"><p>2024-08-10 07:00:00</p><?php echo $apiData['currentDate']['byPrice']['2024-08-10 07:00:00'] ?></div>
                        
                        
                        </div>
                    </div>
                </div>

                </div>
<!-- RIGHT SIDE -->
            <div class="chart-box">
                <div class="chart-container" style="width: 80%; height: 400px; margin: auto;">
                    <canvas id="priceChart"></canvas>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        const apiData2 = <?php echo json_encode($apiData2); ?>;
                        const labels = Object.keys(apiData2.byPriceToday);
                        const data = Object.values(apiData2.byPriceToday);

                        const ctx = document.getElementById('priceChart').getContext('2d');
                        new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [{
                                    label: 'Prices Today',
                                    data: data,
                                    borderColor: 'rgba(75, 192, 192, 1)',
                                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                    borderWidth: 2,
                                    tension: 0.4
                                }]
                            },
                            options: {
                                responsive: true,
                                plugins: {
                                    legend: {
                                        display: true,
                                        position: 'top'
                                    }
                                },
                                scales: {
                                    x: {
                                        title: {
                                            display: true,
                                            text: 'Time (Hours)'
                                        }
                                    },
                                    y: {
                                        title: {
                                            display: true,
                                            text: 'Price'
                                        },
                                        beginAtZero: true
                                    }
                                }
                            }
                        });
                    });
                </script>
<script src="nord2.js"></script>




<link rel="stylesheet" href="nordpoolstyle.css">
</body>
</html>