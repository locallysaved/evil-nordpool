const buttonConfigs = [
    { buttonClass: 'filterByTimeBtn', sectionClass: 'filterByTime' },
    { buttonClass: 'filterByPriceBtn', sectionClass: 'filterByPrice' },
    { buttonClass: 'filterByHappyHrsBtn', sectionClass: 'filterByHappyHrs' }
  ];

  buttonConfigs.forEach(({ buttonClass, sectionClass }) => {
    const button = document.querySelector(`.${buttonClass}`);
    button.addEventListener('click', () => {
      buttonConfigs.forEach(({ sectionClass }) => {
        document.querySelector(`.${sectionClass}`).style.display = 'none';
      });

      document.querySelector(`.${sectionClass}`).style.display = 'block';
    });
  });

